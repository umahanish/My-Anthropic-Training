# CLAUDE.md — Campus Task & Study Group Manager

This file gives Claude Code context when working in this repo. Keep it in
sync with the planning docs stored in the companion Claude Project.

## Project docs (source of truth — read these first for "why")
- `docs/requirements.md` — scope, MVP vs stretch
- `docs/architecture.md` — tech stack, data model, API surface, review checklist
- `docs/product-backlog.md` — epics/stories/acceptance criteria
- `docs/sprint-plan.md` — current sprint, what's in scope right now
- `docs/estimation.md` — effort tracking

## Stack
- Backend: Node.js + Express + Jest/Supertest, SQLite in dev.
- Web: React + Vite.
- Mobile: React Native (Expo).
- All three share the API contract in `docs/architecture.md` §4 — never
  duplicate business logic in a client; clients call the API.

## Working conventions
1. **One backlog item per change.** Reference the backlog ID (e.g. `E2-1`)
   in commit messages and PR descriptions.
2. **Tests are not optional.** Any new business logic in `backend/src` needs
   a corresponding test in `backend/tests`. Run `npm test` before considering
   a task done.
3. **Small commits.** Prefer several small, reviewable commits over one large one.
4. **Code review pass before merge**, using the checklist in
   `docs/architecture.md` §8. When asked to "review" code, apply that
   checklist explicitly and point out concrete line-level issues.
5. **Don't expand scope.** If a task reveals extra work, add it as a new
   backlog item in `docs/product-backlog.md` rather than doing it inline.

## Commands
```
cd backend && npm install && npm test   # run backend unit/integration tests
cd backend && npm run dev               # start API locally
cd web && npm install && npm run dev    # start web client
cd mobile && npm install && npx expo start   # start mobile client (Expo)
```
